def validate_user(user):
    hashed_passw = user.password
    username = user.login
    users_data = open('user_data.txt', 'r')

    for user in users_data.readlines():
        user_data = user.split(' ')
        if username == user_data[0]:
            c = user_data[1][:-1]
            if hashed_passw == user_data[1][:-1]:
                return True

    return False
var loginButton = document.getElementById("login-button");
console.log(loginButton)

function redirectToRegister() {
    window.location = "matyczw/z3/register";
}

loginButton.onclick = redirectToRegister();



import os

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}


def create_user_dir_if_not_exists(username):
    userpath = 'userDirs/' + username + '/'
    if not os.path.exists(userpath):
        os.makedirs(userpath)
    return


def get_user_file_list(user_path):
    return os.listdir(user_path)


def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS
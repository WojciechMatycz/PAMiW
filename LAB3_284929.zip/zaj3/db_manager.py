from zaj3.user import User
import zaj3.validator as validator

def create_user(details_tab):
    userDetails = [details_tab[0], details_tab[1]]
    return User(userDetails)


def add_user_to_db(user):
    if not validator.validate_user(user):
        with open('user_data.txt', 'a') as f:
            f.write(user.to_db_record() + '\n')
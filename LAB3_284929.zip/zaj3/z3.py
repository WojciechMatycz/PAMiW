from flask import Flask, session, request, render_template, redirect, url_for, abort, send_from_directory
from werkzeug.utils import secure_filename
import os
import zaj3.file_manager as f_manager
import zaj3.db_manager as db_manager
import zaj3.validator as validator
from zaj3.user import User

app = Flask(__name__)
app.secret_key = b'tester1209'
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    UPLOAD_FOLDER='userDirs'
)


@app.route('/matyczw/z3/')
def index():
    if session.get('logged'):
        return redirect(url_for('userPage'))
    else:
        return redirect(url_for('login'))


@app.route('/matyczw/z3/login', methods=['POST', 'GET'])
def login():
    if request.args.get('message') is not None:
        return render_template('login.html', message=request.args.get('message'))
    else:
        return render_template('login.html')


@app.route('/matyczw/z3/handle_login', methods=['POST', 'GET'])
def handle_login():
    if request.form['submit-button'] == 'Zarejestruj się':
        return redirect(url_for('register'))
    elif request.form['submit-button'] == 'Zaloguj':
        if validator.validate_user(User([request.form['login'], request.form['password']])):
            session['user'] = request.form['login']
            session['logged'] = True
            return redirect(url_for('userPage'))
        else:
            return redirect(url_for('login', message='Błędny login lub hasło'))


@app.route('/matyczw/z3/userPage', methods=['GET', 'POST'])
def userPage():
    if check_if_user_logged():

        if request.method == 'POST':
            file_name = request.form['save-button']
            path = 'userDirs/' + session['user']
            if os.path.isfile(path + '/' + file_name):
                return send_from_directory(directory=path, filename=file_name, as_attachment=True)
            else:
                abort(404)

        username = session['user']
        f_manager.create_user_dir_if_not_exists(username)
        user_path = 'userDirs/' + username + '/'

        files_list = f_manager.get_user_file_list(user_path)
        number_of_files = count_space_left(user_path)
        if request.args.get('message') is not None:
            return render_template('userPage.html', message=request.args.get('message'), username=username, files=files_list,
                                   number_of_files=number_of_files)
        else:
            return render_template("userPage.html", username=username, files=files_list,
                                   number_of_files=number_of_files)
    else:
        return redirect(url_for('login'))

@app.route('/matyczw/z3/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        c = request.files
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            return redirect(request.url)

        if file and f_manager.allowed_file(file.filename):
            username = session.get('user')
            user_path = 'userDirs/' + username + '/'
            filename = secure_filename(file.filename)
            file.save(os.path.join(user_path, filename))
            return redirect(url_for('userPage', message='Pomyślnie dodano plik'))


@app.route('/matyczw/z3/delete', methods=["POST"])
def delete():
    username = session.get('user')
    user_path = 'userDirs/' + username + '/'
    fname = request.form['delete-button']
    if fname is not None:
        os.remove(user_path + fname)
        return redirect(url_for('userPage'))
    else:
        abort(505)


@app.route('/matyczw/z3/logout', methods=['POST'])
def logout():
    session.pop('user')
    session['logged']=False
    return redirect(url_for('login'))


@app.route('/matyczw/z3/register', methods=['GET'])
def register():
    return render_template('register.html')


@app.route('/matyczw/z3/handle_register', methods=["POST"])
def handle_register():
    if request.form['login'] != '' and request.form['password'] != '':
        user = db_manager.create_user([request.form['login'], request.form['password']])
        db_manager.add_user_to_db(user)
        return redirect(url_for('login', message="Pomyslnie zarejestrowano"))
    else:
        return render_template('register.html', error='Błąd!')


def check_if_user_logged():
    if session.get('logged'):
        return True
    return False


def count_space_left(user_path):
    file_list = f_manager.get_user_file_list(user_path)
    return 5 - len(file_list)


if __name__ == '__main__':
    app.run(debug=True)
